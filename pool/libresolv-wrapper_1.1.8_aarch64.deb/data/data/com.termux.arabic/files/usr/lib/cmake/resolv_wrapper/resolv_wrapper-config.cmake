set(RESOLV_WRAPPER_LIBRARY /data/data/com.termux.arabic/files/usr/lib/libresolv_wrapper.so)
